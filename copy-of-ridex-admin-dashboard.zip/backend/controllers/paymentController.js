
const { Transaction, Ride, User, sequelize } = require('../models');
const { v4: uuidv4 } = require('uuid');

exports.initiatePayment = async (req, res) => {
    const { rideId, amount, mobileNumber, provider } = req.body;
    const io = req.app.get('io');

    console.log(`💰 [PayChangu] Charging ${amount} to ${mobileNumber} (${provider}) for Ride ${rideId}`);

    try {
        // 1. Create Pending Transaction
        const transaction = await Transaction.create({
            userId: req.user.id,
            type: 'Ride Payment',
            amount: amount,
            direction: 'debit',
            status: 'pending',
            reference: `PAY-${uuidv4()}`,
            relatedId: rideId,
            description: `Payment for Ride ${rideId}`
        });

        // 2. Simulate Async Processing & Webhook (3s delay)
        setTimeout(async () => {
            try {
                // Mark Transaction Complete
                await transaction.update({ status: 'completed' });

                // Update Ride Status
                const ride = await Ride.findByPk(rideId);
                if (ride) {
                    const driverShare = amount * 0.9;
                    
                    await ride.update({
                        status: 'Completed',
                        paymentStatus: 'paid',
                        transactionRef: transaction.reference,
                        driverEarnings: driverShare
                    });

                    // Credit Driver Wallet (Atomic increment not supported in simple Sequelize update, need raw query or find+update)
                    const driver = await User.findByPk(ride.driverId);
                    if (driver) {
                        await driver.increment('walletBalance', { by: driverShare });
                    }

                    // Notify Clients via Socket
                    io.to(`ride_${rideId}`).emit('payment_success', { 
                        amount, 
                        transactionRef: transaction.reference 
                    });
                    
                    io.to(`user_${ride.driverId}`).emit('notification', {
                        title: 'Payment Received',
                        msg: `You received MWK ${driverShare} for Ride #${rideId}`,
                        time: 'Just now'
                    });
                }
            } catch (e) {
                console.error("Payment Processing Error", e);
            }
        }, 3000);

        res.json({ 
            status: 'pending', 
            message: 'Mobile money prompt sent.', 
            reference: transaction.reference 
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
