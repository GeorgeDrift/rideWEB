
const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const { authenticateToken } = require('../middleware/auth');

router.post('/initiate', authenticateToken, paymentController.initiatePayment);

module.exports = router;
